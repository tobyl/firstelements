<header class="clearfix">
			
	<h1><a href="index.php" class="ir">First Elements Inc</a></h1>

	<nav>

		<ul>
			<li><a href="services.php">Services</a></li>
			<li><a href="about.php">About</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>

	</nav>

</header>